#ifndef GAME_H
#define GAME_H

#include <QMouseEvent>
#include <QMainWindow>
#include <QLabel>

#include "finished.h"

namespace Ui {
class Game;
}

class Game : public QMainWindow
{
    Q_OBJECT

public:
    explicit Game(QWidget *parent = nullptr, QString chosen = "");
    ~Game();
    void mousePressEvent(QMouseEvent *);
    void readFromFile(QString, QString);
    void createKeyboard();
    const Finished* getFinishedWindow();

public slots:
    void activationTimer();

private:
    Ui::Game *ui;
    Finished *finished;
    QLabel *label[26];
    QString word = "";
    QString word_to_open = "";
    int increment_time = 0;
    int right_guessed_letters_number = 0;
    int wrong_guessed_letter_number = 0;
    bool win = false;
};

#endif // GAME_H
