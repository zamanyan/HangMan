#include "category.h"
#include "ui_category.h"

#include <QListWidgetItem>
#include <QMessageBox>

Category::Category(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Category)
{
    ui->setupUi(this);

    setCategory("MIXED", ":/mixed.png");
    setCategory("ACTORS", ":/actors.png");
    setCategory("COUNTRIES", ":/countries.png");
    setCategory("ANIMALS", ":/animals.png");
    setCategory("FRUITS", ":/fruits.png");
    setCategory("DISNEY CHARACTERS", ":/characters.png");
    setCategory("CARS", ":/cars.png");
    setCategory("SPORT", ":/sport.png");
    setCategory("BRANDS", ":/brands.png");
    setCategory("CITIES", ":/cities.png");
}

Category::~Category()
{
    delete ui;
}

void Category::showCategory()
{
    show();
}

void Category::on_pushButton_clicked()
{
    hide();
    QString chosen = ui->listWidget->currentItem()->text();
    game = new Game(this, chosen);
    connect(game->getFinishedWindow(), SIGNAL(startAgain()), this, SLOT(showCategory()));
    game->show();
}

void Category::setCategory(QString category_name, QString file_name)
{
    QListWidgetItem *item = new QListWidgetItem;
    item->setText(category_name);
    item->setIcon(QIcon(file_name));
    ui->listWidget->addItem(item);
}
