#include "hangman.h"
#include "ui_hangman.h"

#include <QMessageBox>
#include <QPixmap>

HangMan::HangMan(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::HangMan)
{
    ui->setupUi(this);
    QPixmap pix(":/hangman.jpg");
    int w = 171;
    int h = 171;
    ui->label_pic->setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
}

HangMan::~HangMan()
{
    delete ui;
}


void HangMan::on_pushButton_Login_clicked()
{
    QString username = ui->lineEdit_UserName->text();
    QString password = ui->lineEdit_Password->text();

    if (username == "zamanyan.nelly@gmail.com" && password == "Zamanyan")
    {
        hide();
        start = new Start(this);
        start->show();
    }
    else
    {
        QMessageBox::warning(this, "Login", "Wrong Username or Password!");
    }
}
