#ifndef CATEGORY_H
#define CATEGORY_H

#include <QMainWindow>
#include "game.h"

namespace Ui {
class Category;
}

class Category : public QMainWindow
{
    Q_OBJECT

public:
    explicit Category(QWidget *parent = nullptr);
    ~Category();

public slots:
    void showCategory();

private slots:
    void on_pushButton_clicked();
    void setCategory(QString, QString);

private:
    Ui::Category *ui;
    Game *game;
};

#endif // CATEGORY_H
