#ifndef HANGMAN_H
#define HANGMAN_H

#include <QMainWindow>
#include <QList>
#include "start.h"

QT_BEGIN_NAMESPACE
namespace Ui { class HangMan; }
QT_END_NAMESPACE

class HangMan : public QMainWindow
{
    Q_OBJECT

public:
    HangMan(QWidget *parent = nullptr);
    ~HangMan();

private slots:
    void on_pushButton_Login_clicked();

private:
    Ui::HangMan *ui;
    Start *start;
};
#endif // HANGMAN_H
