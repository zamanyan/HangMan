#include "start.h"
#include "ui_start.h"

#include <QPixmap>
#include <QMessageBox>

Start::Start(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Start)
{
    ui->setupUi(this);
    QPixmap pix(":/hangman.jpg");
    int w = 580; //ui->label->width();
    int h = 693; //ui->label->height();
    ui->label->setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
}

Start::~Start()
{
    delete ui;
}

void Start::on_pushButton_clicked()
{
    hide();
    category = new Category(this);
    category->show();
}
