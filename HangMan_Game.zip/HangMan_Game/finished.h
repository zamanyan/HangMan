#ifndef FINISHED_H
#define FINISHED_H

#include <QMainWindow>

namespace Ui {
class Finished;
}

class Finished : public QMainWindow
{
    Q_OBJECT

public:
    explicit Finished(QWidget *parent = nullptr,
                      bool win = false,
                      QString word = "");
    ~Finished();
    void lose_or_win(bool);

private slots:
    void on_Cancel_clicked();
    void on_New_Game_clicked();
signals:
    void startAgain();

private:
    Ui::Finished *ui;
};

#endif // FINISHED_H
