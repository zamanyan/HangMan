#include "finished.h"
#include "ui_finished.h"

#include <QMessageBox>

Finished::Finished(QWidget *parent, bool win, QString word) :
    QMainWindow(parent),
    ui(new Ui::Finished)
{
    ui->setupUi(this);
    //lose_or_win(win);
    ui->label_2->setText(word);
}

Finished::~Finished()
{
    delete ui;
}
/*
void Finished::lose_or_win(bool win)
{
    if (win) {
        ui->label->setText("CORRECT!");
    }
    else {
        ui->label->setText("WRONG!");
    }
}
*/
void Finished::on_Cancel_clicked()
{
    close();
}

void Finished::on_New_Game_clicked()
{
    hide();
    emit startAgain();
}
