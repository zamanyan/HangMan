// zamanyan.nelly@gmail.com
#include "game.h"
#include "ui_game.h"

#include <QRandomGenerator>
#include <QTextStream>
#include <QMessageBox>
#include <QPixmap>
#include <QTimer>
#include <QFile>

Game::Game(QWidget *parent, QString chosen) :
    QMainWindow(parent),
    ui(new Ui::Game)
{
    ui->setupUi(this);
    QPixmap pix(":/hangman0.jpg");
    int w = 441;
    int h = 521;
    ui->label_HangMan->setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
    readFromFile(":/HangMan.txt", chosen);
    createKeyboard();
    finished = new Finished(this, win, word);
}

Game::~Game()
{
    delete ui;
}

void Game::readFromFile(QString file_name, QString chosen)
{
    int line_count(0);
    QFile file_(file_name);
    if (!file_.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(0, "warning", file_.errorString());
    }
    while (!file_.atEnd()) {
        QByteArray line_ = file_.readLine();
        line_count++;
    }

    int line_number(0);
    QString line = "";
    QStringList list;
    if (chosen == "MIXED") {
        QFile file(file_name);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            int rnd_line = QRandomGenerator::global()->bounded(1, line_count);
            QTextStream stream(&file);
            while (!stream.atEnd()) {
                line = stream.readLine();
                if (line_number == rnd_line) {
                    list = line.split(QLatin1Char(','));
                    int rnd_word_pos = QRandomGenerator::global()->bounded(1, list.size());
                    word = list[rnd_word_pos];
                    for (int i = 0; i < word.size(); i++) {
                        if (word[i] != ' ') {
                            word_to_open += "_ ";
                        }
                        else {
                            word_to_open += "  ";
                        }
                    }
                    ui->label->setText(list[0]);
                    ui->label_2->setText(word_to_open);
                }
                line_number++;
            }
            file.close();
        }
        else {
            QMessageBox::warning(0, "warning", file.errorString());
        }
    }
    else {
        QFile file(file_name);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QTextStream stream(&file);
            while (!stream.atEnd()) {
                line = stream.readLine();
                list = line.split(QLatin1Char(','));
                if (list[0] == chosen) {
                    int rnd_pos_from_chosen = QRandomGenerator::global()->bounded(1, list.size());
                    word = list[rnd_pos_from_chosen];
                    for (int i = 0; i < word.size(); i++) {
                        if (word[i] != ' ') {
                            word_to_open += "_ ";
                        }
                        else {
                            word_to_open += "  ";
                        }
                    }
                    ui->label->setText(list[0]);
                    ui->label_2->setText(word_to_open);
                    break;
                }
            }
            file.close();
        }
        else {
            QMessageBox::warning(0, "warning", file.errorString());
        }
    }
}

void Game::createKeyboard()
{
    int c = 0, l = 10, k = 0, z = 0;
    for (int i = 0; i < 26; i++) {
        label[i] = new QLabel(this);
        label[i]->setGeometry(c * 40 + 110 + z, 650 + k * 40, 40, 40);
        label[i]->setText(QString(65 + i));
        c++;
        if (c == l) {
            c = 0;
            l--;
            z += 20;
            k++;
            if (z == 40) {
                z += 20;
            }
        }
    }
}

const Finished *Game::getFinishedWindow()
{
    return finished;
}

void Game::mousePressEvent(QMouseEvent *event)
{
    int u, v, size = 40, letters_from = 0, letters_to = 0;
    int x = 0, y = 0;
    int c = event->x();
    int k = event->y();

    if (k >= 650 && k <= 690) {
        letters_from = 0;
        letters_to = 10;
        x = 110;
        y = 650;
    }
    else if (k >= 690 && k <= 730) {
        letters_from = 10;
        letters_to = 19;
        x = 130;
        y = 690;
    }
    else if (k >= 730 && k <= 770) {
        letters_from = 19;
        letters_to = 26;
        x = 170;
        y = 730;
    }
    c -= x;   u = c / size;
    k -= y;   v = k / size;
    c = u * size + x;
    k = v * size + y;

    QString clicked_label_letter = "";
    for(int i = letters_from; i < letters_to; i++) {
        if(label[i]->x() == c && label[i]->y() == k) {
            clicked_label_letter = label[i]->text();
            label[i]->clear();
            break;
        }
    }

    if (clicked_label_letter.size() != 0) {
        int word_length(0);    // without whitespaces
        for (int i = 0; i < word.size(); i++) {
            if (word[i] != ' ') {
                word_length++;
            }
        }

        bool letter_is_founded = false;
        for (int j = 0; j < word.size(); j++) {
            if (clicked_label_letter == word[j]) {
                letter_is_founded = true;
                word_to_open[j + j] = word[j];
                ui->label_2->setText(word_to_open);
                right_guessed_letters_number++;
                if (right_guessed_letters_number == word_length) {
                    win = true;
                    QTimer *timer = new QTimer(this);
                    connect(timer, SIGNAL(timeout()), this, SLOT(activationTimer()));
                    timer->start(500);
                }
            }
        }

        if (!letter_is_founded) {
            wrong_guessed_letter_number++;
            if (wrong_guessed_letter_number != 7) {
                QString next_pic = ":/hangman";
                next_pic.append(QString::number(wrong_guessed_letter_number));
                next_pic.append(".jpg");
                QPixmap pix(next_pic);
                int w = 441;
                int h = 521;
                ui->label_HangMan->setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
            }
            else {
                QString next_pic = ":/hangman";
                next_pic.append(QString::number(wrong_guessed_letter_number));
                next_pic.append(".jpg");
                QPixmap pix(next_pic);
                int w = 441;
                int h = 521;
                ui->label_HangMan->setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
                QTimer *timer = new QTimer(this);
                connect(timer, SIGNAL(timeout()), this, SLOT(activationTimer()));
                timer->start(500);
            }
        }
    }
}

void Game::activationTimer()
{
    increment_time++;
    if (increment_time == 3) {
        hide();
        finished->show();
    }
}
